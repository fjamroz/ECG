var class_qwt_spline_curve_fitter =
[
    [ "FitMode", "class_qwt_spline_curve_fitter.html#a8c5e6858f885b5691c30092a950879a8", [
      [ "Auto", "class_qwt_spline_curve_fitter.html#a8c5e6858f885b5691c30092a950879a8ae19b8325da178d410cf10b04ed5a5df6", null ],
      [ "Spline", "class_qwt_spline_curve_fitter.html#a8c5e6858f885b5691c30092a950879a8a97f3e821b70470f056b60a883229ec13", null ],
      [ "ParametricSpline", "class_qwt_spline_curve_fitter.html#a8c5e6858f885b5691c30092a950879a8a877f71e694ae9a2e33533a3fb5065c66", null ]
    ] ],
    [ "QwtSplineCurveFitter", "class_qwt_spline_curve_fitter.html#a98ae80240b254df85dcc44e1f3e4e830", null ],
    [ "~QwtSplineCurveFitter", "class_qwt_spline_curve_fitter.html#a933ecbf859698978104d0dd4ec2a2f6a", null ],
    [ "fitCurve", "class_qwt_spline_curve_fitter.html#a14d64180d7777d0cd9c2adf81e120140", null ],
    [ "fitMode", "class_qwt_spline_curve_fitter.html#a473468f2151839f3290975f6b18f1c4f", null ],
    [ "setFitMode", "class_qwt_spline_curve_fitter.html#a8381be57ee16b5a2bdacafbd5d71908b", null ],
    [ "setSpline", "class_qwt_spline_curve_fitter.html#a7f819ad010b19d58179655e4ceb1c6f1", null ],
    [ "setSplineSize", "class_qwt_spline_curve_fitter.html#a8ecea80fb540b92cd22b6b0703636460", null ],
    [ "spline", "class_qwt_spline_curve_fitter.html#a7e5211e9e84df705d8bbbc7a57fbfa6d", null ],
    [ "spline", "class_qwt_spline_curve_fitter.html#ac501260a25953e1ded6bbc84c3250fa8", null ],
    [ "splineSize", "class_qwt_spline_curve_fitter.html#a09e5cb291c90db0aa8e6e51377bc9308", null ]
];
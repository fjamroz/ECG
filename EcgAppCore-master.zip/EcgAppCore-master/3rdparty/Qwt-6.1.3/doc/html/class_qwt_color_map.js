var class_qwt_color_map =
[
    [ "Format", "class_qwt_color_map.html#a9e5570790910fa3894887bca7dc5a670", [
      [ "RGB", "class_qwt_color_map.html#a9e5570790910fa3894887bca7dc5a670a663473fd836d9a84fe48ae1755de326a", null ],
      [ "Indexed", "class_qwt_color_map.html#a9e5570790910fa3894887bca7dc5a670a304cb055c004223ca77f1a4cbbf27ea2", null ]
    ] ],
    [ "QwtColorMap", "class_qwt_color_map.html#a2ab0a6041ea6d37c0609ca2e3bd976ca", null ],
    [ "~QwtColorMap", "class_qwt_color_map.html#af20e4ffdb3c5d34f5a6dc301bcbb9f7e", null ],
    [ "color", "class_qwt_color_map.html#a35f74175e963d18e451a9fd4421ede1f", null ],
    [ "colorIndex", "class_qwt_color_map.html#a8fc538cb07efb7ad05a3d3f7426320ba", null ],
    [ "colorTable", "class_qwt_color_map.html#a4ccc23356e058783071b06dee437b6d7", null ],
    [ "format", "class_qwt_color_map.html#a436802833ae1d4694f376655bc3d75be", null ],
    [ "rgb", "class_qwt_color_map.html#af33fa8c5ac1aa9583f2e1d4a109a6c5f", null ]
];
var class_qwt_curve_fitter =
[
    [ "~QwtCurveFitter", "class_qwt_curve_fitter.html#a62919f309f0441d94adea94573d0f778", null ],
    [ "QwtCurveFitter", "class_qwt_curve_fitter.html#ad804660017ae0f3ede604470724b3df3", null ],
    [ "fitCurve", "class_qwt_curve_fitter.html#a84e96e917bf522c1137e03c0ebb231ef", null ]
];
var class_qwt_weeding_curve_fitter =
[
    [ "QwtWeedingCurveFitter", "class_qwt_weeding_curve_fitter.html#a7deb4d070a329cbdee454023194898a7", null ],
    [ "~QwtWeedingCurveFitter", "class_qwt_weeding_curve_fitter.html#abbd30a948fc6974f881678f80a29768c", null ],
    [ "chunkSize", "class_qwt_weeding_curve_fitter.html#a280b4984a2b2c67f9863bb27e2bb3ed3", null ],
    [ "fitCurve", "class_qwt_weeding_curve_fitter.html#aa316dc6c60ae0d0c74ef0bc0fc239f0b", null ],
    [ "setChunkSize", "class_qwt_weeding_curve_fitter.html#a9f17a819447cba0e733bd71d90ee2766", null ],
    [ "setTolerance", "class_qwt_weeding_curve_fitter.html#a62c303f6826fef2be7b7bbe82f530680", null ],
    [ "tolerance", "class_qwt_weeding_curve_fitter.html#aa2e69ce083d02c4da0d669a082a15187", null ]
];
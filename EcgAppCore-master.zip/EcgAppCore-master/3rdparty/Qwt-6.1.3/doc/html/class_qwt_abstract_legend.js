var class_qwt_abstract_legend =
[
    [ "QwtAbstractLegend", "class_qwt_abstract_legend.html#a77092d06decd579fcde5c90875c3830b", null ],
    [ "~QwtAbstractLegend", "class_qwt_abstract_legend.html#a6d86d9c50679dea9fefafc457fc70814", null ],
    [ "isEmpty", "class_qwt_abstract_legend.html#a177cb553f60c0446cdef9e7ace916641", null ],
    [ "renderLegend", "class_qwt_abstract_legend.html#a3656b3d4dcf572c0b4134b9988c975f6", null ],
    [ "scrollExtent", "class_qwt_abstract_legend.html#a51e8c45d2afc691e78b09c662d7a493e", null ],
    [ "updateLegend", "class_qwt_abstract_legend.html#aa9fc80c9e1dcbcfef51b96a3bff268ca", null ]
];
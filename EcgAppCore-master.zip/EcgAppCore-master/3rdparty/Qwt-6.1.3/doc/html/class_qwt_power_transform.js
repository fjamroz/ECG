var class_qwt_power_transform =
[
    [ "QwtPowerTransform", "class_qwt_power_transform.html#af29ae09162f70bdf81bc5a6fabcb84ba", null ],
    [ "~QwtPowerTransform", "class_qwt_power_transform.html#a33a82c2e0a67e7463646e7dbb64ccff1", null ],
    [ "copy", "class_qwt_power_transform.html#a1c3833f1f275ac298b3986cddc67055e", null ],
    [ "invTransform", "class_qwt_power_transform.html#aae19e2002b08ab09ed177d8ff6753f82", null ],
    [ "transform", "class_qwt_power_transform.html#aad3892cb63f5981521184960e240a4f3", null ]
];
var class_qwt_compass_rose =
[
    [ "~QwtCompassRose", "class_qwt_compass_rose.html#a9e3e5086d7225152cad3a276096753be", null ],
    [ "draw", "class_qwt_compass_rose.html#a977c1fbfb502f67e04466d1ebc327a40", null ],
    [ "palette", "class_qwt_compass_rose.html#ab2e5c2a4a27c40a175458b96d89394e8", null ],
    [ "setPalette", "class_qwt_compass_rose.html#ad69f887ed012d6bf6bf2ffeb133e26d5", null ]
];
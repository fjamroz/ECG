var class_qwt_plot_magnifier =
[
    [ "QwtPlotMagnifier", "class_qwt_plot_magnifier.html#a6edabe11a02cae3ae8e8adaa9013d109", null ],
    [ "~QwtPlotMagnifier", "class_qwt_plot_magnifier.html#a38c0508241885ea49542cc0f11c740df", null ],
    [ "canvas", "class_qwt_plot_magnifier.html#a833e0c42a9ffdc92a60a1d1b0828b8ec", null ],
    [ "canvas", "class_qwt_plot_magnifier.html#a435c1df676fcfcc27206e2746137aadf", null ],
    [ "isAxisEnabled", "class_qwt_plot_magnifier.html#acb4c33465bdd3c19c07ea3fa836c1f8d", null ],
    [ "plot", "class_qwt_plot_magnifier.html#ae0197fb4f393e149585ff62f8e29cea6", null ],
    [ "plot", "class_qwt_plot_magnifier.html#a2cc4ae00009f34f54880aea9e9837826", null ],
    [ "rescale", "class_qwt_plot_magnifier.html#a271ae5ad42c3dd12812246d2dee687ea", null ],
    [ "setAxisEnabled", "class_qwt_plot_magnifier.html#ac8806df408b5ed9eac79cd38e5fc1508", null ]
];
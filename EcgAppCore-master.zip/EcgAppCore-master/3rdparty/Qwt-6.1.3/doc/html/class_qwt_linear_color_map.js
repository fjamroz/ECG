var class_qwt_linear_color_map =
[
    [ "Mode", "class_qwt_linear_color_map.html#ac8c5f1991f533b1d25a9a0a0874b7d54", [
      [ "FixedColors", "class_qwt_linear_color_map.html#ac8c5f1991f533b1d25a9a0a0874b7d54a564b5243ab2c5e4c972a6b645234c651", null ],
      [ "ScaledColors", "class_qwt_linear_color_map.html#ac8c5f1991f533b1d25a9a0a0874b7d54a01770189cb40240f2fe7fe2e6c1523f1", null ]
    ] ],
    [ "QwtLinearColorMap", "class_qwt_linear_color_map.html#a0ef6a29bb027017aad89a4c4a4b07019", null ],
    [ "QwtLinearColorMap", "class_qwt_linear_color_map.html#ae591cf441db15a021c25d0b58bfa7a5e", null ],
    [ "~QwtLinearColorMap", "class_qwt_linear_color_map.html#a82caa759e44d439aa9866bd03e2e3696", null ],
    [ "addColorStop", "class_qwt_linear_color_map.html#aa7162a034e882e752c15051439bb2c99", null ],
    [ "color1", "class_qwt_linear_color_map.html#a3ab5066b01409f58e4ad0425474b1530", null ],
    [ "color2", "class_qwt_linear_color_map.html#a9fa696fff9ec599f0c305f73345ecab3", null ],
    [ "colorIndex", "class_qwt_linear_color_map.html#aa69528213eb7d484466f095c8a9a6efe", null ],
    [ "colorStops", "class_qwt_linear_color_map.html#afaafe752db9de97ec6fba163515f51dd", null ],
    [ "mode", "class_qwt_linear_color_map.html#a9ec309df6ec88472a63b14ac2c692c96", null ],
    [ "rgb", "class_qwt_linear_color_map.html#ac031babccc90d8c857c707d0841ba1eb", null ],
    [ "setColorInterval", "class_qwt_linear_color_map.html#abfae35c30755c0bbd1447342055e9a13", null ],
    [ "setMode", "class_qwt_linear_color_map.html#afca7397fb6d07d05bab83e83e274a9c2", null ]
];
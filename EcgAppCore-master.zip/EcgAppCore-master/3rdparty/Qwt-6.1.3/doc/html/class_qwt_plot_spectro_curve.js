var class_qwt_plot_spectro_curve =
[
    [ "PaintAttributes", "class_qwt_plot_spectro_curve.html#a78b3bf4c7d055f2f00bd371e9ddc4f2f", null ],
    [ "PaintAttribute", "class_qwt_plot_spectro_curve.html#af6d4c6ae392f3f521db710484a059625", [
      [ "ClipPoints", "class_qwt_plot_spectro_curve.html#af6d4c6ae392f3f521db710484a059625ab8586d2301ec1e0888f852bca84c2501", null ]
    ] ],
    [ "QwtPlotSpectroCurve", "class_qwt_plot_spectro_curve.html#aa02c00eb35a6f08ab11091ef66c737cd", null ],
    [ "QwtPlotSpectroCurve", "class_qwt_plot_spectro_curve.html#a78170049ecb2b6681a107abf26783bd7", null ],
    [ "~QwtPlotSpectroCurve", "class_qwt_plot_spectro_curve.html#a8246490aaa9d47e77f5596f56fb073d6", null ],
    [ "colorMap", "class_qwt_plot_spectro_curve.html#a901a8ee5d6aa7b6e41eadf8f1bdc1e03", null ],
    [ "colorRange", "class_qwt_plot_spectro_curve.html#aa495f44361e659e5fd83882e21e56542", null ],
    [ "drawDots", "class_qwt_plot_spectro_curve.html#af6f48a0334d5646e2def2b3bfd16754c", null ],
    [ "drawSeries", "class_qwt_plot_spectro_curve.html#a04529b82d2acbcf9fc8f66da73bae8e9", null ],
    [ "penWidth", "class_qwt_plot_spectro_curve.html#a81a531d89ac21d25e86a958822720f38", null ],
    [ "rtti", "class_qwt_plot_spectro_curve.html#a5e866a7b7c024d26329814745ca2379c", null ],
    [ "setColorMap", "class_qwt_plot_spectro_curve.html#a67d046af16feeddc9bec08c698b46446", null ],
    [ "setColorRange", "class_qwt_plot_spectro_curve.html#a133f4117e925a1faed456bd9524477e4", null ],
    [ "setPaintAttribute", "class_qwt_plot_spectro_curve.html#a3a2ddc8e46bc4414b5ce104e7c70f9b4", null ],
    [ "setPenWidth", "class_qwt_plot_spectro_curve.html#ac3246da1a881538149addc2f22401578", null ],
    [ "setSamples", "class_qwt_plot_spectro_curve.html#a668926af2266515a5d82911ac81262ca", null ],
    [ "setSamples", "class_qwt_plot_spectro_curve.html#a6374cf95ed6731d098328f2b8c317a8c", null ],
    [ "testPaintAttribute", "class_qwt_plot_spectro_curve.html#abd7f7eb2830b0dfb7f6211f0b252088e", null ]
];
var class_qwt_dial_needle =
[
    [ "QwtDialNeedle", "class_qwt_dial_needle.html#aef3af79632ce784bc4d7332f6e269a1f", null ],
    [ "~QwtDialNeedle", "class_qwt_dial_needle.html#ac23b2af4af50042967c8cea87b474247", null ],
    [ "draw", "class_qwt_dial_needle.html#a425085086c4a8c7baff10b161616ee42", null ],
    [ "drawKnob", "class_qwt_dial_needle.html#aaca9572717a1db10b1b6609571024688", null ],
    [ "drawNeedle", "class_qwt_dial_needle.html#a3893ef0232ba0e000d3d33a0cb541dd1", null ],
    [ "palette", "class_qwt_dial_needle.html#a8b3c915032389261e07cc983b433166c", null ],
    [ "setPalette", "class_qwt_dial_needle.html#ae850883a64501136bca64d6ea2d084b9", null ]
];
var class_qwt_event_pattern_1_1_mouse_pattern =
[
    [ "MousePattern", "class_qwt_event_pattern_1_1_mouse_pattern.html#a4233e9620cdad92c498a5271cd32bcf6", null ],
    [ "button", "class_qwt_event_pattern_1_1_mouse_pattern.html#ade5b5bdb3bf76814f003c02ea11c5924", null ],
    [ "modifiers", "class_qwt_event_pattern_1_1_mouse_pattern.html#ad12c724aac7bba9f16540c604dc108f9", null ]
];
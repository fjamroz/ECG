var class_qwt_compass_magnet_needle =
[
    [ "Style", "class_qwt_compass_magnet_needle.html#aee1d882c6ec8b680b94b59b5710a92a5", [
      [ "TriangleStyle", "class_qwt_compass_magnet_needle.html#aee1d882c6ec8b680b94b59b5710a92a5ad2ba960c4dae88e36da39f6b62798f3b", null ],
      [ "ThinStyle", "class_qwt_compass_magnet_needle.html#aee1d882c6ec8b680b94b59b5710a92a5ab63a2dd26ef14c2aaf9763bc24a8bdac", null ]
    ] ],
    [ "QwtCompassMagnetNeedle", "class_qwt_compass_magnet_needle.html#a3422e6490d44c527289bafdcceecd741", null ],
    [ "drawNeedle", "class_qwt_compass_magnet_needle.html#aa052d929a09bfc6d487a973b2221d44d", null ]
];
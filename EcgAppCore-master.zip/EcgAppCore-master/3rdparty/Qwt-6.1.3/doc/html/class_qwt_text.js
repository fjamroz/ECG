var class_qwt_text =
[
    [ "LayoutAttributes", "class_qwt_text.html#aadd451b81d506c5bbefdddb8a100b9a3", null ],
    [ "PaintAttributes", "class_qwt_text.html#a0d239ca5c8e0cd3c748325ad453bb13f", null ],
    [ "LayoutAttribute", "class_qwt_text.html#a0953aabc098f410dba89bbada47f2e5a", [
      [ "MinimumLayout", "class_qwt_text.html#a0953aabc098f410dba89bbada47f2e5aa35990c4c74747580e9357d490ebce42f", null ]
    ] ],
    [ "PaintAttribute", "class_qwt_text.html#a9739e47ea489e690f121e4b1d27ae24e", [
      [ "PaintUsingTextFont", "class_qwt_text.html#a9739e47ea489e690f121e4b1d27ae24eac12e48f17fd02a6bc1840c61c4862a65", null ],
      [ "PaintUsingTextColor", "class_qwt_text.html#a9739e47ea489e690f121e4b1d27ae24ea1aa48cee0a54089820e77600cf93dc4b", null ],
      [ "PaintBackground", "class_qwt_text.html#a9739e47ea489e690f121e4b1d27ae24ea77dd66b2a65e9998d9803672791e1456", null ]
    ] ],
    [ "TextFormat", "class_qwt_text.html#a63e0d6a59a427a37ed0bfa71b782fd76", [
      [ "AutoText", "class_qwt_text.html#a63e0d6a59a427a37ed0bfa71b782fd76a0645d333081ec9e3574c98f510c284a1", null ],
      [ "PlainText", "class_qwt_text.html#a63e0d6a59a427a37ed0bfa71b782fd76aa6810f6d3c785c202d2507c601b97787", null ],
      [ "RichText", "class_qwt_text.html#a63e0d6a59a427a37ed0bfa71b782fd76a88f7eee487ce6f7769b67494623d8b79", null ],
      [ "MathMLText", "class_qwt_text.html#a63e0d6a59a427a37ed0bfa71b782fd76abf479897e4514198246a0b232a597caf", null ],
      [ "TeXText", "class_qwt_text.html#a63e0d6a59a427a37ed0bfa71b782fd76af31a767faf2f7e322941866c6140ddc6", null ],
      [ "OtherFormat", "class_qwt_text.html#a63e0d6a59a427a37ed0bfa71b782fd76ad69e3155611ef96eb14ed0cfeb69fd3d", null ]
    ] ],
    [ "QwtText", "class_qwt_text.html#a91439964ad1150c136dcaa113a648ecf", null ],
    [ "QwtText", "class_qwt_text.html#af88b42733c420574fa76b2d58b965313", null ],
    [ "~QwtText", "class_qwt_text.html#aba243ac11b91979ad3f2ee7d3c700195", null ],
    [ "backgroundBrush", "class_qwt_text.html#a46bb4836482e4fe554f5079871343ba6", null ],
    [ "borderPen", "class_qwt_text.html#ae06c3ab1a6396962e4035e7ec1452db6", null ],
    [ "borderRadius", "class_qwt_text.html#a21b879281d4e07f5ffe6e4465c176dc1", null ],
    [ "color", "class_qwt_text.html#a8904020d2a906c4c66d8515ba47820fe", null ],
    [ "draw", "class_qwt_text.html#a01efd3ff82db2018b742265e0b7e4ece", null ],
    [ "font", "class_qwt_text.html#a76db41eeae98fbfa0933a38328a240ac", null ],
    [ "heightForWidth", "class_qwt_text.html#a29f7064fa8825d30e0b7b7b740d2df9f", null ],
    [ "isEmpty", "class_qwt_text.html#a25843b1120b648752ed5be2247ebe43f", null ],
    [ "isNull", "class_qwt_text.html#afdf53f75d1b8ce6f2f0b00df59fa0177", null ],
    [ "operator!=", "class_qwt_text.html#a092326f250d2b865ad93f16462d9fc9f", null ],
    [ "operator=", "class_qwt_text.html#ad4a8678071c7e114c47a21f1f78cca37", null ],
    [ "operator==", "class_qwt_text.html#a0a7fba648ad898d751de60e9a6d7802f", null ],
    [ "renderFlags", "class_qwt_text.html#a59c6bf54af867ce5632a07117fe442e1", null ],
    [ "setBackgroundBrush", "class_qwt_text.html#af016a747b234aede9f0cbbeb06ed2802", null ],
    [ "setBorderPen", "class_qwt_text.html#aca4dd700b7a182114a8c0eb864c4ec2f", null ],
    [ "setBorderRadius", "class_qwt_text.html#a7c62dfe82aa94f113cd4f8702bd2242c", null ],
    [ "setColor", "class_qwt_text.html#ac7de5839a5c3b1ee367cfbd5691aa105", null ],
    [ "setFont", "class_qwt_text.html#ad071f3c4fae4512a1cc71554d95eb69a", null ],
    [ "setLayoutAttribute", "class_qwt_text.html#a2b621d3104ead2185d2d939b1f5b9d68", null ],
    [ "setPaintAttribute", "class_qwt_text.html#aac80e3f05137173059b196206ceea9e8", null ],
    [ "setRenderFlags", "class_qwt_text.html#a2e71d427de766455323794f27d369a5d", null ],
    [ "setText", "class_qwt_text.html#a9ba9caa82fcfbc4bfbf8ce20ccea981e", null ],
    [ "testLayoutAttribute", "class_qwt_text.html#a5b7bddee1d80139b93d60a0a3a044944", null ],
    [ "testPaintAttribute", "class_qwt_text.html#a53c4bcae538e272660d33bed6f71f01b", null ],
    [ "text", "class_qwt_text.html#a15a42a83153f82bab8cfc283d090d736", null ],
    [ "textSize", "class_qwt_text.html#a62537933249b2f967b54468360d41519", null ],
    [ "usedColor", "class_qwt_text.html#a1496bcc9225230c4da25ea73ba0a345a", null ],
    [ "usedFont", "class_qwt_text.html#a9769ab68a4fe26025c4172a14092f792", null ]
];
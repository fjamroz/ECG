var class_qwt_plain_text_engine =
[
    [ "QwtPlainTextEngine", "class_qwt_plain_text_engine.html#a0ad29b2229a879afe49b546704eb7079", null ],
    [ "~QwtPlainTextEngine", "class_qwt_plain_text_engine.html#a0ada8796b2caaff7bb8d61e9fb1b5143", null ],
    [ "draw", "class_qwt_plain_text_engine.html#a5fc2780c10ac2fb41aec91223b60fac7", null ],
    [ "heightForWidth", "class_qwt_plain_text_engine.html#a9190bdcb6ed447a5bc056ad8304ad58b", null ],
    [ "mightRender", "class_qwt_plain_text_engine.html#ae7bd7417f0173e2d35fe1bf7a514ec9b", null ],
    [ "textMargins", "class_qwt_plain_text_engine.html#ac209b74082557d3086cb3b52f99c522d", null ],
    [ "textSize", "class_qwt_plain_text_engine.html#a220628c0e315021a3ae9d4447bf88018", null ]
];
var class_qwt_dial_simple_needle =
[
    [ "Style", "class_qwt_dial_simple_needle.html#ad28821489e04f1fd942e5bebc8a60584", [
      [ "Arrow", "class_qwt_dial_simple_needle.html#ad28821489e04f1fd942e5bebc8a60584a27ace220f0a5c6abd061c85bbdc9a663", null ],
      [ "Ray", "class_qwt_dial_simple_needle.html#ad28821489e04f1fd942e5bebc8a60584a580980e68ef26fc7d35962cf6f12a4b2", null ]
    ] ],
    [ "QwtDialSimpleNeedle", "class_qwt_dial_simple_needle.html#a5f16b9298ecd293360a3ccf91d3dbfbb", null ],
    [ "drawNeedle", "class_qwt_dial_simple_needle.html#a0eff8832707ff968d17eddf478d6a771", null ],
    [ "setWidth", "class_qwt_dial_simple_needle.html#ad7672543371e38c864e44d9240271c22", null ],
    [ "width", "class_qwt_dial_simple_needle.html#af7c8d5ed409364e4e67b7e40f1c0cfe2", null ]
];
var class_qwt_plot_g_l_canvas =
[
    [ "Shadow", "class_qwt_plot_g_l_canvas.html#a6ce3b3cb6888443dfadca2399a632830", [
      [ "Plain", "class_qwt_plot_g_l_canvas.html#a6ce3b3cb6888443dfadca2399a632830a2d5a783769032359be64ff1d1a6c9143", null ],
      [ "Raised", "class_qwt_plot_g_l_canvas.html#a6ce3b3cb6888443dfadca2399a632830a51c9540f673ec613857453927dc084cf", null ],
      [ "Sunken", "class_qwt_plot_g_l_canvas.html#a6ce3b3cb6888443dfadca2399a632830ae707e3b005592b559a8093b94b08d9c0", null ]
    ] ],
    [ "Shape", "class_qwt_plot_g_l_canvas.html#abb14b54c316ea3b3d39dee1dc0e78849", [
      [ "NoFrame", "class_qwt_plot_g_l_canvas.html#abb14b54c316ea3b3d39dee1dc0e78849aaf9c223aac7c31c6832c3a1c2bd9a516", null ],
      [ "Box", "class_qwt_plot_g_l_canvas.html#abb14b54c316ea3b3d39dee1dc0e78849a06c7aee3854655b45bfe87c5f5f8cdc6", null ],
      [ "Panel", "class_qwt_plot_g_l_canvas.html#abb14b54c316ea3b3d39dee1dc0e78849ae11eda296e5152706eb3474e51c4f98d", null ]
    ] ],
    [ "QwtPlotGLCanvas", "class_qwt_plot_g_l_canvas.html#adc7704723f078ff57243a2e2fc217832", null ],
    [ "~QwtPlotGLCanvas", "class_qwt_plot_g_l_canvas.html#a330939a56e289c42bcfbee2d82ef8347", null ],
    [ "borderPath", "class_qwt_plot_g_l_canvas.html#a09dbce4a8649eaa31910cb51147d2b41", null ],
    [ "drawBackground", "class_qwt_plot_g_l_canvas.html#a7d829159155bff3fe206101914feeb26", null ],
    [ "drawBorder", "class_qwt_plot_g_l_canvas.html#a9dc8018e6144788fe75dfc62206c1fe4", null ],
    [ "drawItems", "class_qwt_plot_g_l_canvas.html#a0b385f2230b2abddf85882dbdfd89a34", null ],
    [ "event", "class_qwt_plot_g_l_canvas.html#a9345f69cd3c96c5cb4bdcc3d056de8dd", null ],
    [ "frameRect", "class_qwt_plot_g_l_canvas.html#a0288ef4d408f6f270fedb895436acc89", null ],
    [ "frameShadow", "class_qwt_plot_g_l_canvas.html#a331133679651f7d08cfad03b7d723691", null ],
    [ "frameShape", "class_qwt_plot_g_l_canvas.html#a06d846c980148c1b258baea8ba0b2d68", null ],
    [ "frameStyle", "class_qwt_plot_g_l_canvas.html#ae5e8b391cd2ec58d0483a4dd7db5f395", null ],
    [ "frameWidth", "class_qwt_plot_g_l_canvas.html#a39bc67f5fd7c4adb8ac5f5a4e43d9d68", null ],
    [ "lineWidth", "class_qwt_plot_g_l_canvas.html#af171f7b3727852df3062a975251eb976", null ],
    [ "midLineWidth", "class_qwt_plot_g_l_canvas.html#af4d70838d3af7c8521fe313b813c347e", null ],
    [ "paintEvent", "class_qwt_plot_g_l_canvas.html#aa0bf3be03e9545b78da74844e6f4eb91", null ],
    [ "replot", "class_qwt_plot_g_l_canvas.html#af2bf82a971fcea76dab92da15a859c67", null ],
    [ "setFrameShadow", "class_qwt_plot_g_l_canvas.html#aee1da52928fa1fb765fa9c5794f40a4a", null ],
    [ "setFrameShape", "class_qwt_plot_g_l_canvas.html#a579e3f0891236317742cb58d9cacb6f5", null ],
    [ "setFrameStyle", "class_qwt_plot_g_l_canvas.html#a9e1a08cbed3d6fb4ba89a31591265d0d", null ],
    [ "setLineWidth", "class_qwt_plot_g_l_canvas.html#a9b831253eef4f77a0f580468cb5e41d6", null ],
    [ "setMidLineWidth", "class_qwt_plot_g_l_canvas.html#a529cce50eea2c9a46fe9c41852f6cee3", null ]
];
var class_qwt_legend_data =
[
    [ "Mode", "class_qwt_legend_data.html#aaa33cc8e6aec17440df5d4c38d7545b7", [
      [ "ReadOnly", "class_qwt_legend_data.html#aaa33cc8e6aec17440df5d4c38d7545b7add4342fbe2d82828b9ef7031c1b41a0b", null ],
      [ "Clickable", "class_qwt_legend_data.html#aaa33cc8e6aec17440df5d4c38d7545b7a39077c66db9fe2faf4d85a6f9266583f", null ],
      [ "Checkable", "class_qwt_legend_data.html#aaa33cc8e6aec17440df5d4c38d7545b7a250e05444c9927d83d3815d9f5593917", null ]
    ] ],
    [ "Role", "class_qwt_legend_data.html#a55bd21943c804101d956250ca43f93f9", [
      [ "ModeRole", "class_qwt_legend_data.html#a55bd21943c804101d956250ca43f93f9a4b558c65e634d5d467e1cda869aa576b", null ],
      [ "TitleRole", "class_qwt_legend_data.html#a55bd21943c804101d956250ca43f93f9a4d8e06d686916e2377f90b4eb1099080", null ],
      [ "IconRole", "class_qwt_legend_data.html#a55bd21943c804101d956250ca43f93f9a705dc61ee2bdfb3575cd89b6fb7e797f", null ],
      [ "UserRole", "class_qwt_legend_data.html#a55bd21943c804101d956250ca43f93f9a068a16339054e86f69c8406f52eafac0", null ]
    ] ],
    [ "QwtLegendData", "class_qwt_legend_data.html#a519e4f01583d051e4b2458ab9dfcb196", null ],
    [ "~QwtLegendData", "class_qwt_legend_data.html#a56608cc97875e7b3dd9340decd5231cb", null ],
    [ "hasRole", "class_qwt_legend_data.html#ae615eb3d1a3d88cc25dc0ed6dea70a72", null ],
    [ "icon", "class_qwt_legend_data.html#a3a4e20d33c2eb8bec1e8ef9b943de74c", null ],
    [ "isValid", "class_qwt_legend_data.html#a4f77fc2e39d6187fb58aeb964049b4c6", null ],
    [ "mode", "class_qwt_legend_data.html#a7cd0c8df579edddf8abfe6c7a87af07f", null ],
    [ "setValue", "class_qwt_legend_data.html#a1be4b4cf3c1df733744633ea6c02346a", null ],
    [ "setValues", "class_qwt_legend_data.html#a68c3bc398c541f345a12fa9321ad52ed", null ],
    [ "title", "class_qwt_legend_data.html#a23d0faa63f590c1f0c3ee7c9479410cf", null ],
    [ "value", "class_qwt_legend_data.html#a73016050ce489f85018025ec5a268387", null ],
    [ "values", "class_qwt_legend_data.html#aeecadb69ee0e384b34f4b39a2131924e", null ]
];
var class_qwt_simple_compass_rose =
[
    [ "QwtSimpleCompassRose", "class_qwt_simple_compass_rose.html#a66cc98efe5717eaf11fb0e713cd1aa21", null ],
    [ "~QwtSimpleCompassRose", "class_qwt_simple_compass_rose.html#a157304c9a535126d33a80df9a9dad292", null ],
    [ "draw", "class_qwt_simple_compass_rose.html#aa7541cd32c88b222731da37588e67bf3", null ],
    [ "numThornLevels", "class_qwt_simple_compass_rose.html#a8fa418ee344d934d556fa5719cd5ece5", null ],
    [ "numThorns", "class_qwt_simple_compass_rose.html#a7c3270789e94e94b8d515b04372bfe0b", null ],
    [ "setNumThornLevels", "class_qwt_simple_compass_rose.html#ad91026da3b586a3193a264401221a275", null ],
    [ "setNumThorns", "class_qwt_simple_compass_rose.html#a3c86abb463eb4741d1776318d6fa557b", null ],
    [ "setShrinkFactor", "class_qwt_simple_compass_rose.html#afaf84e19eb8eb2360306860b02d46cfc", null ],
    [ "setWidth", "class_qwt_simple_compass_rose.html#ae4067a436f45d2f2ca23d8233539566b", null ],
    [ "shrinkFactor", "class_qwt_simple_compass_rose.html#a49ac7941c4a09f5a33e660b130d7bc2e", null ],
    [ "width", "class_qwt_simple_compass_rose.html#a28e7dcd6574c6239f5d15cdda93ac835", null ]
];
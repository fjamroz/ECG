var class_qwt_plot_text_label =
[
    [ "QwtPlotTextLabel", "class_qwt_plot_text_label.html#a19466cb637c30cfce5abfe024cbc3e3a", null ],
    [ "~QwtPlotTextLabel", "class_qwt_plot_text_label.html#a20e024910ca49b8fd7326cbfca77df22", null ],
    [ "draw", "class_qwt_plot_text_label.html#adfb623425eb95dcfe6fb18c661d04ebe", null ],
    [ "invalidateCache", "class_qwt_plot_text_label.html#ac498a144d548eddd4209da5979815c76", null ],
    [ "margin", "class_qwt_plot_text_label.html#a259ab949f5434091f34fe71b12ec72ab", null ],
    [ "rtti", "class_qwt_plot_text_label.html#a6478e871cb51ee383e82c437cf6dbf86", null ],
    [ "setMargin", "class_qwt_plot_text_label.html#a28bba339d2996ae2a8a426575820a816", null ],
    [ "setText", "class_qwt_plot_text_label.html#adce2e99ef7816ff544c5a5525bf05006", null ],
    [ "text", "class_qwt_plot_text_label.html#ae1e2796dce184885e871a7b8981e3bac", null ],
    [ "textRect", "class_qwt_plot_text_label.html#ac5b13cbdd6334b05ff4961494755add4", null ]
];